<?php
/**
 * @file
 * Contains constants class.
 */

/**
 * @file
 * This class represents constants used throughout project.
 */
namespace Drupal\miniorange_saml_idp; 

class MiniorangeSAMLIdpConstants {

  const BASE_URL = 'https://auth.miniorange.com';

}

