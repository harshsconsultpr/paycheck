document.getElementById('doItYourselfButton').onclick = function() {
	window.location="https://auth.miniorange.com/moas/login?redirectUrl=https://auth.miniorange.com/moas/initializepayment&requestOrigin=drupal_saml_sso_upgrade_plan";
}