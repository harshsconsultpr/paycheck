<?php
namespace Drupal\miniorange_saml;

/**
 * @file
 * This class represents constants used throughout project.
 */
class MiniorangeSAMLConstants {

  const BASE_URL = 'https://auth.miniorange.com';

}
